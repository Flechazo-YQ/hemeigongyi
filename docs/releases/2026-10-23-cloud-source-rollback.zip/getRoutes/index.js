// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const PENDING_STATUSES = ['pending', '待处理', '待审核']
const INACTIVE_STATUSES = ['已拒绝', 'rejected', '已取消', 'cancelled']

async function getPendingCounts(collectionName, routeField, routeIds) {
  if (!routeIds.length) return {}

  const $ = db.command.aggregate
  const { data } = await db.collection(collectionName)
    .aggregate()
    .match({
      [routeField]: $.in([`$${routeField}`, routeIds]),
      status: $.in(['$status', PENDING_STATUSES])
    })
    .group({
      _id: `$${routeField}`,
      pendingCount: $.sum(1)
    })
    .end()

  return data.reduce((counts, item) => {
    counts[String(item._id)] = item.pendingCount
    return counts
  }, {})
}

async function getActiveRegistrationCounts(collectionName, routeField, routeIds) {
  const counts = {}
  const pageSize = 100

  for (let index = 0; index < routeIds.length; index += 20) {
    const ids = routeIds.slice(index, index + 20)
    let skip = 0

    while (true) {
      const { data } = await db.collection(collectionName)
        .where({ [routeField]: db.command.in(ids) })
        .skip(skip)
        .limit(pageSize)
        .get()

      data.forEach(record => {
        if (!INACTIVE_STATUSES.includes(record.status)) {
          const routeId = String(record[routeField])
          counts[routeId] = (counts[routeId] || 0) + 1
        }
      })

      if (data.length < pageSize) break
      skip += data.length
    }
  }

  return counts
}

// 云函数入口函数
exports.main = async (event, context) => {
  // 强制返回测试数据，验证云函数是否执行
  const testResponse = {
    success: true,
    data: {
      routes: [
        {
          _id: 'test-route-001',
          title: '测试路线 - 云函数已部署',
          category: 'STEAM专区',
          start_date: '2024-01-15',
          end_date: '2024-01-16',
          place: '测试地点',
          quota: 20,
          current_count: 5,
          enabled: true
        }
      ],
      deployInfo: {
        functionName: 'getRoutes',
        deployTime: new Date().toISOString(),
        env: cloud.DYNAMIC_CURRENT_ENV,
        version: '1.0.2',
        message: '这是云端部署的云函数'
      }
    }
  }
  
  console.log('=== getRoutes 云函数开始执行 ===')
  console.log('这是云端部署的云函数版本 1.0.2')
  console.log('接收到的参数:', event)
  
  try {
    const { category, includePendingCount } = event
    
    console.log('开始查询数据库...')
    
    // 构建查询条件
    let whereCondition = { enabled: true }
    
    // 如果指定了分类且不是全部，则添加分类筛选
    if (category && category !== '全部') {
      console.log('添加分类筛选:', category)
      whereCondition.category = category
    }
    
    console.log('查询条件:', whereCondition)
    
    // 执行查询
    const result = await db.collection('research_routes')
      .where(whereCondition)
      .orderBy('start_date', 'desc')
      .get()
    
    console.log('查询结果:', result)
    console.log('数据条数:', result.data ? result.data.length : 0)
    
    // 如果有数据库数据，使用数据库数据；否则返回空数组
    if (result.data && result.data.length > 0) {
      let routes = result.data;
      const volunteerRouteIds = routes
        .filter(route => route.type === 'volunteer')
        .map(route => route._id)
      const studyRouteIds = routes
        .filter(route => route.type !== 'volunteer')
        .map(route => route._id)
      const [volunteerRegistrationCounts, studyRegistrationCounts] = await Promise.all([
        getActiveRegistrationCounts('volunteer_registrations', 'task_id', volunteerRouteIds),
        getActiveRegistrationCounts('registrations', 'route_id', studyRouteIds)
      ])

      routes = routes.map(route => {
        const isVolunteer = route.type === 'volunteer'
        const countField = isVolunteer ? 'volunteer_count' : 'current_count'
        const count = (isVolunteer ? volunteerRegistrationCounts : studyRegistrationCounts)[String(route._id)] || 0
        return { ...route, [countField]: count }
      })

      // 如果需要统计待审核数量
      if (includePendingCount) {
        console.log('开始统计待审核数量...');
        const [volunteerCounts, studyCounts] = await Promise.all([
          getPendingCounts('volunteer_registrations', 'task_id', volunteerRouteIds).catch(error => {
            console.error('统计志愿者待审核数失败:', error)
            return {}
          }),
          getPendingCounts('registrations', 'route_id', studyRouteIds).catch(error => {
            console.error('统计研学待审核数失败:', error)
            return {}
          })
        ])

        routes = routes.map(route => {
          const pendingCounts = route.type === 'volunteer' ? volunteerCounts : studyCounts
          return {
            ...route,
            pendingCount: pendingCounts[String(route._id)] || 0
          }
        })
        console.log('统计完成');
      }

      return {
        success: true,
        data: {
          routes: routes,
          deployInfo: {
            functionName: 'getRoutes',
            deployTime: new Date().toISOString(),
            env: cloud.DYNAMIC_CURRENT_ENV,
            version: '1.0.4',
            message: '使用数据库数据'
          }
        }
      }
    } else {
      console.log('数据库无数据')
      return {
        success: true,
        data: {
          routes: []
        }
      }
    }
    
  } catch (error) {
    console.error('=== getRoutes 云函数执行错误 ===')
    console.error('错误详情:', error)
    
    return {
      success: false,
      error: error.message
    }
  }
}
