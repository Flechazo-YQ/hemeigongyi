// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    console.log('submitRegistration 开始执行，参数:', event)
    
    const { route_id, childName, childGender, childAge, parentPhone } = event
    
    // 基础数据验证
    if (!route_id || !childName || !childGender || !childAge || !parentPhone) {
      return {
        success: false,
        error: '请填写完整信息'
      }
    }
    
    // 手机号格式验证
    const phoneRegex = /^1[3-9]\d{9}$/
    if (!phoneRegex.test(parentPhone)) {
      return {
        success: false,
        error: '手机号格式不正确'
      }
    }
    
    // 年龄验证
    const age = parseInt(childAge)
    if (age < 3 || age > 18) {
      return {
        success: false,
        error: '年龄需在3-18岁'
      }
    }
    
    console.log('数据验证通过，开始检查路线')
    
    // 检查路线是否存在
    const routeResult = await db.collection('research_routes').doc(route_id).get()
    if (!routeResult.data) {
      return {
        success: false,
        error: '路线不存在'
      }
    }
    
    const route = routeResult.data
    console.log('路线信息:', route)
    
    // 检查名额
    if (route.current_count >= route.quota) {
      return {
        success: false,
        error: '名额已满'
      }
    }
    
    console.log('名额检查通过，开始创建报名记录')
    
    // 创建报名记录
    const wxContext = cloud.getWXContext()
    const openid = wxContext.OPENID
    const now = new Date()
    const registrationData = {
      _openid: openid, // 手动添加 openid
      route_id: route_id,
      route_title: route.title, // 保存路线标题
      child_name: childName,
      child_gender: childGender,
      child_age: age,
      parent_phone: parentPhone,
      status: 'pending', // 统一状态值为 pending/approved/rejected
      create_time: now,
      update_time: now
    }
    
    console.log('报名数据:', registrationData)
    
    const registrationResult = await db.collection('registrations').add({
      data: registrationData
    })
    
    console.log('报名记录创建成功:', registrationResult)
    
    // 更新路线报名数
    await db.collection('research_routes').doc(route_id).update({
      data: {
        current_count: db.command.inc(1),
        update_time: now
      }
    })
    
    console.log('路线报名数更新成功')
    
    return {
      success: true,
      message: '报名成功',
      data: {
        registration_id: registrationResult._id
      }
    }
    
  } catch (error) {
    console.error('submitRegistration 执行错误:', error)
    return {
      success: false,
      error: error.message
    }
  }
} 